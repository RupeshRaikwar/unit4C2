const express = require("express");


const connect = require("./configs/db");

const app = express();

app.use(express.json());

app.use("/user",userController);
app.use("/branch",branchController);
app.use("/master",masterController);
app.use("/saving",savingController);
app.use("/fixed",fixedController);


app.listen(3200, async() =>{
    try{
        await connect();
        console.log("listning to port 3200");
    }
    catch(err){
        console.log(err);
    }
    
})