const mongoose = require("mongoose");

const MasterAccountSchema = new mongoose.Schema(
    {
        balance:{type:Number, required:true},
        user_id:{type:mongoose.Schema.Types.ObjectId , ref:"user"},
        branch_id:{type:mongoose.Schema.Types.ObjectId , ref:"branch"},
    },
    {
        versionkey:false,
        timestamps:true,
    }
);



module.exports = mongoose.model("master",MasterAccountSchema);


//balance (required) This is the total balance that the person has in the bank
// createdAt (required)
// updatedAt (required)