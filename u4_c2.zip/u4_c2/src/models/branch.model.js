
const mongoose = require("mongoose");

const BranchdetailSchema = new mongoose.Schema(
    {
        name:{type:String , required:true},
        address:{type:String , required:true},
        IFSC:{type:String , required:true},
        MICR:{type:String , required:true},
    },
    {
        versionkey:false,
        timestamps:true,
    }
);

module.exports = mongoose.model("branch",BranchdetailSchema);












// name (required)
// address (required)
// IFSC (required and string)
// MICR (required and number )
// createdAt (required)
// updatedAt (required)