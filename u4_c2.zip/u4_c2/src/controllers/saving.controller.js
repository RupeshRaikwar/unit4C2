const express = require("express");

const Saving = require("../models/saving.model");

const router = express.Router();

router.get("", async (req,res)=>{
    try {
        const users = await User.find().lean().exec();
        return res.send(users);
    } catch (error) {
        res.send(error);
    }
});

router.get("/:id", async (req,res)=>{
    try {
        const userid = await User.findById(req.params.id).lean().exec();
        return res.send(userid);
    } catch (error) {
        res.send(error);
    }
});

router.post("", async (req,res)=>{
    try {
        const post = await User.create(req.body);
        return res.send(post);
    } catch (error) {
        res.send(error);
    }
});


router.patch("/:id", async (req,res)=>{
    try {
        const change = await User.findByIdAndUpdate(req.params.id , req.body ,{
            new:true,
        });
        return res.send(change);
    } catch (error) {
        res.send(error);
    }
});



router.delete("/:id", async (req,res)=>{
    try {
        const dele = await User.findByIdAndDelete(req.params.id);
        return res.send(dele);
    } catch (error) {
        res.send(error);
    }
});

module.exports = router ;