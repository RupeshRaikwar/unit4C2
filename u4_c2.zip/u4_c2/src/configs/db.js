
const mongoose = require("mongoose");

module.exports = () => {
    return mongoose.connect("mongodb+srv://sbi:sbi123@cluster0.3uome.mongodb.net/bank?retryWrites=true&w=majority");
};